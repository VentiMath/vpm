"use strict";

/**
 * A minimal path module to resolve Unix, Windows and URL paths alike.
 * @memberof util
 * @namespace
 */
var path = exports;

var urlRe = /^[a-zA-Z][a-zA-Z0-9+.-]+:\/\//;

function normalizeUrl(path) {
    if (typeof URL === "undefined" || !urlRe.test(path))
        return null;
    try {
        return new URL(path).href;
    } catch (e) {
        return null;
    }
}

function resolveUrl(originPath, includePath) {
    if (typeof URL === "undefined" || !urlRe.test(originPath) || urlRe.test(includePath))
        return null;
    try {
        return new URL(includePath, originPath).href;
    } catch (e) {
        return null;
    }
}

var isAbsolute =
/**
 * Tests if the specified path is absolute.
 * @param {string} path Path to test
 * @returns {boolean} `true` if path is absolute
 */
path.isAbsolute = function isAbsolute(path) {
    return /^(?:\/|\w+:|\\\\\w+)/.test(path);
};

var normalize =
/**
 * Normalizes the specified path.
 * @param {string} path Path to normalize
 * @returns {string} Normalized path
 */
path.normalize = function normalize(path) {
    var normalizedUrl = normalizeUrl(path);
    if (normalizedUrl)
        return normalizedUrl;
    var firstTwoCharacters = path.substring(0,2);
    var uncPrefix = "";
    if (firstTwoCharacters === "\\\\") {
        uncPrefix = firstTwoCharacters;
        path = path.substring(2);
    }

    path = path.replace(/\\/g, "/")
               .replace(/\/{2,}/g, "/");
    var parts    = path.split("/"),
        absolute = isAbsolute(path),
        prefix   = "";
    if (absolute)
        prefix = parts.shift() + "/";
    for (var i = 0; i < parts.length;) {
        if (parts[i] === "..") {
            if (i > 0 && parts[i - 1] !== "..")
                parts.splice(--i, 2);
            else if (absolute)
                parts.splice(i, 1);
            else
                ++i;
        } else if (parts[i] === ".")
            parts.splice(i, 1);
        else
            ++i;
    }
    return uncPrefix + prefix + parts.join("/");
};

/**
 * Resolves the specified include path against the specified origin path.
 * @param {string} originPath Path to the origin file
 * @param {string} includePath Include path relative to origin path
 * @param {boolean} [alreadyNormalized=false] `true` if both paths are already known to be normalized
 * @returns {string} Path to the include file
 */
path.resolve = function resolve(originPath, includePath, alreadyNormalized) {
    var resolvedUrl = resolveUrl(originPath, includePath);
    if (resolvedUrl)
        return resolvedUrl;
    if (!alreadyNormalized)
        includePath = normalize(includePath); // path or absolute url
    if (isAbsolute(includePath))
        return includePath;
    if (!alreadyNormalized)
        originPath = normalize(originPath);
    return (originPath = originPath.replace(/(?:\/|^)[^/]+$/, "")).length ? normalize(originPath + "/" + includePath) : includePath;
};
