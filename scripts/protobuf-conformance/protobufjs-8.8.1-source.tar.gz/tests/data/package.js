/*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-mixed-operators, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars, default-case, jsdoc/require-param*/
"use strict";

var $protobuf = require("../../minimal");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;
var $Object = $util.global.Object, $undefined = $util.global.undefined, $Error = $util.global.Error, $RangeError = $util.global.RangeError, $Array = $util.global.Array, $TypeError = $util.global.TypeError, $String = $util.global.String;

// Exported root namespace
var $root = $protobuf.roots["test_package"] || ($protobuf.roots["test_package"] = {});

$root.Package = (function() {

    /**
     * Properties of a Package.
     * @typedef {Object} Package.$Properties
     * @property {string|null} [name] Package name
     * @property {string|null} [version] Package version
     * @property {string|null} [versionScheme] Package versionScheme
     * @property {string|null} [description] Package description
     * @property {string|null} [author] Package author
     * @property {string|null} [license] Package license
     * @property {Package.Repository.$Properties|null} [repository] Package repository
     * @property {string|null} [bugs] Package bugs
     * @property {string|null} [homepage] Package homepage
     * @property {Array.<string>|null} [keywords] Package keywords
     * @property {string|null} [main] Package main
     * @property {Object.<string,string>|null} [bin] Package bin
     * @property {Object.<string,string>|null} [scripts] Package scripts
     * @property {Object.<string,string>|null} [dependencies] Package dependencies
     * @property {Object.<string,string>|null} [devDependencies] Package devDependencies
     * @property {string|null} [types] Package types
     * @property {Array.<string>|null} [cliDependencies] Package cliDependencies
     * @property {Array.<Uint8Array>} [$unknowns] Unknown fields preserved while decoding when enabled
     */

    /**
     * Properties of a Package.
     * @exports IPackage
     * @interface IPackage
     * @augments Package.$Properties
     * @deprecated Use Package.$Properties instead.
     */

    /**
     * Shape of a Package.
     * @typedef {Package.$Properties} Package.$Shape
     */

    /**
     * Constructs a new Package.
     * @exports Package
     * @classdesc Represents a Package.
     * @constructor
     * @param {Package.$Properties=} [properties] Properties to set
     * @property {Array.<Uint8Array>} [$unknowns] Unknown fields preserved while decoding when enabled
     */
    var Package = function (properties) {
        this.keywords = [];
        this.bin = {};
        this.scripts = {};
        this.dependencies = {};
        this.devDependencies = {};
        this.cliDependencies = [];
        if (properties)
            for (var keys = $Object.keys(properties), i = 0; i < keys.length; ++i)
                if (properties[keys[i]] != null && keys[i] !== "__proto__")
                    this[keys[i]] = properties[keys[i]];
    };

    /**
     * Package name.
     * @member {string} name
     * @memberof Package
     * @instance
     */
    Package.prototype.name = "";

    /**
     * Package version.
     * @member {string} version
     * @memberof Package
     * @instance
     */
    Package.prototype.version = "";

    /**
     * Package versionScheme.
     * @member {string} versionScheme
     * @memberof Package
     * @instance
     */
    Package.prototype.versionScheme = "";

    /**
     * Package description.
     * @member {string} description
     * @memberof Package
     * @instance
     */
    Package.prototype.description = "";

    /**
     * Package author.
     * @member {string} author
     * @memberof Package
     * @instance
     */
    Package.prototype.author = "";

    /**
     * Package license.
     * @member {string} license
     * @memberof Package
     * @instance
     */
    Package.prototype.license = "";

    /**
     * Package repository.
     * @member {Package.Repository.$Properties|null|undefined} repository
     * @memberof Package
     * @instance
     */
    Package.prototype.repository = null;

    /**
     * Package bugs.
     * @member {string} bugs
     * @memberof Package
     * @instance
     */
    Package.prototype.bugs = "";

    /**
     * Package homepage.
     * @member {string} homepage
     * @memberof Package
     * @instance
     */
    Package.prototype.homepage = "";

    /**
     * Package keywords.
     * @member {Array.<string>} keywords
     * @memberof Package
     * @instance
     */
    Package.prototype.keywords = $util.emptyArray;

    /**
     * Package main.
     * @member {string} main
     * @memberof Package
     * @instance
     */
    Package.prototype.main = "";

    /**
     * Package bin.
     * @member {Object.<string,string>} bin
     * @memberof Package
     * @instance
     */
    Package.prototype.bin = $util.emptyObject;

    /**
     * Package scripts.
     * @member {Object.<string,string>} scripts
     * @memberof Package
     * @instance
     */
    Package.prototype.scripts = $util.emptyObject;

    /**
     * Package dependencies.
     * @member {Object.<string,string>} dependencies
     * @memberof Package
     * @instance
     */
    Package.prototype.dependencies = $util.emptyObject;

    /**
     * Package devDependencies.
     * @member {Object.<string,string>} devDependencies
     * @memberof Package
     * @instance
     */
    Package.prototype.devDependencies = $util.emptyObject;

    /**
     * Package types.
     * @member {string} types
     * @memberof Package
     * @instance
     */
    Package.prototype.types = "";

    /**
     * Package cliDependencies.
     * @member {Array.<string>} cliDependencies
     * @memberof Package
     * @instance
     */
    Package.prototype.cliDependencies = $util.emptyArray;

    /**
     * Creates a new Package instance using the specified properties.
     * @function create
     * @memberof Package
     * @static
     * @param {Package.$Properties=} [properties] Properties to set
     * @returns {Package} Package instance
     * @type {{
     *   (properties: Package.$Shape): Package & Package.$Shape;
     *   (properties?: Package.$Properties): Package;
     * }}
     */
    Package.create = function(properties) {
        return new Package(properties);
    };

    /**
     * Encodes the specified Package message. Does not implicitly {@link Package.verify|verify} messages.
     * @function encode
     * @memberof Package
     * @static
     * @param {Package.$Properties} message Package message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */
    Package.encode = function (message, writer, _depth) {
        if (!writer)
            writer = $Writer.create();
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            throw $Error("max depth exceeded");
        if (message.name != null && $Object.hasOwnProperty.call(message, "name") && message.name !== "")
            writer.uint32(/* id 1, wireType 2 =*/10).string(message.name);
        if (message.version != null && $Object.hasOwnProperty.call(message, "version") && message.version !== "")
            writer.uint32(/* id 2, wireType 2 =*/18).string(message.version);
        if (message.description != null && $Object.hasOwnProperty.call(message, "description") && message.description !== "")
            writer.uint32(/* id 3, wireType 2 =*/26).string(message.description);
        if (message.author != null && $Object.hasOwnProperty.call(message, "author") && message.author !== "")
            writer.uint32(/* id 4, wireType 2 =*/34).string(message.author);
        if (message.license != null && $Object.hasOwnProperty.call(message, "license") && message.license !== "")
            writer.uint32(/* id 5, wireType 2 =*/42).string(message.license);
        if (message.repository != null && $Object.hasOwnProperty.call(message, "repository"))
            $root.Package.Repository.encode(message.repository, writer.uint32(/* id 6, wireType 2 =*/50).fork(), _depth + 1).ldelim();
        if (message.bugs != null && $Object.hasOwnProperty.call(message, "bugs") && message.bugs !== "")
            writer.uint32(/* id 7, wireType 2 =*/58).string(message.bugs);
        if (message.homepage != null && $Object.hasOwnProperty.call(message, "homepage") && message.homepage !== "")
            writer.uint32(/* id 8, wireType 2 =*/66).string(message.homepage);
        if (message.keywords != null && message.keywords.length)
            for (var i = 0; i < message.keywords.length; ++i)
                writer.uint32(/* id 9, wireType 2 =*/74).string(message.keywords[i]);
        if (message.main != null && $Object.hasOwnProperty.call(message, "main") && message.main !== "")
            writer.uint32(/* id 10, wireType 2 =*/82).string(message.main);
        if (message.bin != null && $Object.hasOwnProperty.call(message, "bin"))
            for (var keys = $Object.keys(message.bin), i = 0; i < keys.length; ++i)
                writer.uint32(/* id 11, wireType 2 =*/90).fork().uint32(/* id 1, wireType 2 =*/10).string(keys[i]).uint32(/* id 2, wireType 2 =*/18).string(message.bin[keys[i]]).ldelim();
        if (message.scripts != null && $Object.hasOwnProperty.call(message, "scripts"))
            for (var keys = $Object.keys(message.scripts), i = 0; i < keys.length; ++i)
                writer.uint32(/* id 12, wireType 2 =*/98).fork().uint32(/* id 1, wireType 2 =*/10).string(keys[i]).uint32(/* id 2, wireType 2 =*/18).string(message.scripts[keys[i]]).ldelim();
        if (message.dependencies != null && $Object.hasOwnProperty.call(message, "dependencies"))
            for (var keys = $Object.keys(message.dependencies), i = 0; i < keys.length; ++i)
                writer.uint32(/* id 13, wireType 2 =*/106).fork().uint32(/* id 1, wireType 2 =*/10).string(keys[i]).uint32(/* id 2, wireType 2 =*/18).string(message.dependencies[keys[i]]).ldelim();
        if (message.devDependencies != null && $Object.hasOwnProperty.call(message, "devDependencies"))
            for (var keys = $Object.keys(message.devDependencies), i = 0; i < keys.length; ++i)
                writer.uint32(/* id 15, wireType 2 =*/122).fork().uint32(/* id 1, wireType 2 =*/10).string(keys[i]).uint32(/* id 2, wireType 2 =*/18).string(message.devDependencies[keys[i]]).ldelim();
        if (message.types != null && $Object.hasOwnProperty.call(message, "types") && message.types !== "")
            writer.uint32(/* id 17, wireType 2 =*/138).string(message.types);
        if (message.cliDependencies != null && message.cliDependencies.length)
            for (var i = 0; i < message.cliDependencies.length; ++i)
                writer.uint32(/* id 18, wireType 2 =*/146).string(message.cliDependencies[i]);
        if (message.versionScheme != null && $Object.hasOwnProperty.call(message, "versionScheme") && message.versionScheme !== "")
            writer.uint32(/* id 19, wireType 2 =*/154).string(message.versionScheme);
        if (message.$unknowns != null && $Object.hasOwnProperty.call(message, "$unknowns"))
            for (var i = 0; i < message.$unknowns.length; ++i)
                writer.raw(message.$unknowns[i]);
        return writer;
    };

    /**
     * Encodes the specified Package message, length delimited. Does not implicitly {@link Package.verify|verify} messages.
     * @function encodeDelimited
     * @memberof Package
     * @static
     * @param {Package.$Properties} message Package message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */
    Package.encodeDelimited = function(message, writer) {
        return this.encode(message, (writer || $Writer.create()).fork()).ldelim();
    };

    /**
     * Decodes a Package message from the specified reader or buffer.
     * @function decode
     * @memberof Package
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {Package & Package.$Shape} Package
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */
    Package.decode = function (reader, length, _end, _depth, _target) {
        if (!(reader instanceof $Reader))
            reader = $Reader.create(reader);
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $Reader.recursionLimit)
            throw $Error("max depth exceeded");
        var end, message, key, value;
        if (length === $undefined)
            end = reader.len;
        else {
            end = reader.pos + length;
            if (end > reader.len)
                throw $RangeError("index out of range");
            length = reader.len;
            reader.len = end;
        }
        message = _target || new $root.Package();
        while (reader.pos < end) {
            var start = reader.pos;
            var tag = reader.tag();
            if (tag === _end) {
                _end = $undefined;
                break;
            }
            var wireType = tag & 7;
            switch (tag >>>= 3) {
            case 1: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.name = value;
                    else
                        delete message.name;
                    continue;
                }
            case 2: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.version = value;
                    else
                        delete message.version;
                    continue;
                }
            case 19: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.versionScheme = value;
                    else
                        delete message.versionScheme;
                    continue;
                }
            case 3: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.description = value;
                    else
                        delete message.description;
                    continue;
                }
            case 4: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.author = value;
                    else
                        delete message.author;
                    continue;
                }
            case 5: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.license = value;
                    else
                        delete message.license;
                    continue;
                }
            case 6: {
                    if (wireType !== 2)
                        break;
                    message.repository = $root.Package.Repository.decode(reader, reader.size(), $undefined, _depth + 1, message.repository);
                    continue;
                }
            case 7: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.bugs = value;
                    else
                        delete message.bugs;
                    continue;
                }
            case 8: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.homepage = value;
                    else
                        delete message.homepage;
                    continue;
                }
            case 9: {
                    if (wireType !== 2)
                        break;
                    if (!(message.keywords && message.keywords.length))
                        message.keywords = [];
                    message.keywords.push(reader.stringVerify());
                    continue;
                }
            case 10: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.main = value;
                    else
                        delete message.main;
                    continue;
                }
            case 11: {
                    if (wireType !== 2)
                        break;
                    if (message.bin === $util.emptyObject)
                        message.bin = {};
                    var end2 = reader.size() + reader.pos;
                    if (end2 > reader.len)
                        throw $RangeError("index out of range");
                    reader.len = end2;
                    key = "";
                    value = "";
                    while (reader.pos < end2) {
                        var tag2 = reader.tag();
                        wireType = tag2 & 7;
                        switch (tag2 >>>= 3) {
                        case 1:
                            if (wireType !== 2)
                                break;
                            key = reader.stringVerify();
                            continue;
                        case 2:
                            if (wireType !== 2)
                                break;
                            value = reader.stringVerify();
                            continue;
                        }
                        reader.skipType(wireType, _depth, tag2);
                    }
                    if (reader.pos !== end2)
                        throw $RangeError("index out of range");
                    reader.len = end;
                    if (key === "__proto__")
                        $util.makeProp(message.bin, key);
                    message.bin[key] = value;
                    continue;
                }
            case 12: {
                    if (wireType !== 2)
                        break;
                    if (message.scripts === $util.emptyObject)
                        message.scripts = {};
                    var end2 = reader.size() + reader.pos;
                    if (end2 > reader.len)
                        throw $RangeError("index out of range");
                    reader.len = end2;
                    key = "";
                    value = "";
                    while (reader.pos < end2) {
                        var tag2 = reader.tag();
                        wireType = tag2 & 7;
                        switch (tag2 >>>= 3) {
                        case 1:
                            if (wireType !== 2)
                                break;
                            key = reader.stringVerify();
                            continue;
                        case 2:
                            if (wireType !== 2)
                                break;
                            value = reader.stringVerify();
                            continue;
                        }
                        reader.skipType(wireType, _depth, tag2);
                    }
                    if (reader.pos !== end2)
                        throw $RangeError("index out of range");
                    reader.len = end;
                    if (key === "__proto__")
                        $util.makeProp(message.scripts, key);
                    message.scripts[key] = value;
                    continue;
                }
            case 13: {
                    if (wireType !== 2)
                        break;
                    if (message.dependencies === $util.emptyObject)
                        message.dependencies = {};
                    var end2 = reader.size() + reader.pos;
                    if (end2 > reader.len)
                        throw $RangeError("index out of range");
                    reader.len = end2;
                    key = "";
                    value = "";
                    while (reader.pos < end2) {
                        var tag2 = reader.tag();
                        wireType = tag2 & 7;
                        switch (tag2 >>>= 3) {
                        case 1:
                            if (wireType !== 2)
                                break;
                            key = reader.stringVerify();
                            continue;
                        case 2:
                            if (wireType !== 2)
                                break;
                            value = reader.stringVerify();
                            continue;
                        }
                        reader.skipType(wireType, _depth, tag2);
                    }
                    if (reader.pos !== end2)
                        throw $RangeError("index out of range");
                    reader.len = end;
                    if (key === "__proto__")
                        $util.makeProp(message.dependencies, key);
                    message.dependencies[key] = value;
                    continue;
                }
            case 15: {
                    if (wireType !== 2)
                        break;
                    if (message.devDependencies === $util.emptyObject)
                        message.devDependencies = {};
                    var end2 = reader.size() + reader.pos;
                    if (end2 > reader.len)
                        throw $RangeError("index out of range");
                    reader.len = end2;
                    key = "";
                    value = "";
                    while (reader.pos < end2) {
                        var tag2 = reader.tag();
                        wireType = tag2 & 7;
                        switch (tag2 >>>= 3) {
                        case 1:
                            if (wireType !== 2)
                                break;
                            key = reader.stringVerify();
                            continue;
                        case 2:
                            if (wireType !== 2)
                                break;
                            value = reader.stringVerify();
                            continue;
                        }
                        reader.skipType(wireType, _depth, tag2);
                    }
                    if (reader.pos !== end2)
                        throw $RangeError("index out of range");
                    reader.len = end;
                    if (key === "__proto__")
                        $util.makeProp(message.devDependencies, key);
                    message.devDependencies[key] = value;
                    continue;
                }
            case 17: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.types = value;
                    else
                        delete message.types;
                    continue;
                }
            case 18: {
                    if (wireType !== 2)
                        break;
                    if (!(message.cliDependencies && message.cliDependencies.length))
                        message.cliDependencies = [];
                    message.cliDependencies.push(reader.stringVerify());
                    continue;
                }
            }
            reader.skipType(wireType, _depth, tag);
            if (!reader.discardUnknown) {
                $util.makeProp(message, "$unknowns", false);
                (message.$unknowns || (message.$unknowns = [])).push(reader.raw(start, reader.pos));
            }
        }
        if (length !== $undefined) {
            if (reader.pos !== end)
                throw $RangeError("index out of range");
            reader.len = length;
        }
        if (_end !== $undefined)
            throw $Error("missing end group");
        return message;
    };

    /**
     * Decodes a Package message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof Package
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {Package & Package.$Shape} Package
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */
    Package.decodeDelimited = function(reader) {
        if (!(reader instanceof $Reader))
            reader = new $Reader(reader);
        return this.decode(reader, reader.size());
    };

    /**
     * Verifies a Package message.
     * @function verify
     * @memberof Package
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */
    Package.verify = function (message, _depth) {
        if (typeof message !== "object" || message === null)
            return "object expected";
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            return "max depth exceeded";
        if (message.name != null && $Object.hasOwnProperty.call(message, "name"))
            if (!$util.isString(message.name))
                return "name: string expected";
        if (message.version != null && $Object.hasOwnProperty.call(message, "version"))
            if (!$util.isString(message.version))
                return "version: string expected";
        if (message.versionScheme != null && $Object.hasOwnProperty.call(message, "versionScheme"))
            if (!$util.isString(message.versionScheme))
                return "versionScheme: string expected";
        if (message.description != null && $Object.hasOwnProperty.call(message, "description"))
            if (!$util.isString(message.description))
                return "description: string expected";
        if (message.author != null && $Object.hasOwnProperty.call(message, "author"))
            if (!$util.isString(message.author))
                return "author: string expected";
        if (message.license != null && $Object.hasOwnProperty.call(message, "license"))
            if (!$util.isString(message.license))
                return "license: string expected";
        if (message.repository != null && $Object.hasOwnProperty.call(message, "repository")) {
            var error = $root.Package.Repository.verify(message.repository, _depth + 1);
            if (error)
                return "repository." + error;
        }
        if (message.bugs != null && $Object.hasOwnProperty.call(message, "bugs"))
            if (!$util.isString(message.bugs))
                return "bugs: string expected";
        if (message.homepage != null && $Object.hasOwnProperty.call(message, "homepage"))
            if (!$util.isString(message.homepage))
                return "homepage: string expected";
        if (message.keywords != null && $Object.hasOwnProperty.call(message, "keywords")) {
            if (!$Array.isArray(message.keywords))
                return "keywords: array expected";
            for (var i = 0; i < message.keywords.length; ++i)
                if (!$util.isString(message.keywords[i]))
                    return "keywords: string[] expected";
        }
        if (message.main != null && $Object.hasOwnProperty.call(message, "main"))
            if (!$util.isString(message.main))
                return "main: string expected";
        if (message.bin != null && $Object.hasOwnProperty.call(message, "bin")) {
            if (!$util.isObject(message.bin))
                return "bin: object expected";
            var key = $Object.keys(message.bin);
            for (var i = 0; i < key.length; ++i)
                if (!$util.isString(message.bin[key[i]]))
                    return "bin: string{k:string} expected";
        }
        if (message.scripts != null && $Object.hasOwnProperty.call(message, "scripts")) {
            if (!$util.isObject(message.scripts))
                return "scripts: object expected";
            var key = $Object.keys(message.scripts);
            for (var i = 0; i < key.length; ++i)
                if (!$util.isString(message.scripts[key[i]]))
                    return "scripts: string{k:string} expected";
        }
        if (message.dependencies != null && $Object.hasOwnProperty.call(message, "dependencies")) {
            if (!$util.isObject(message.dependencies))
                return "dependencies: object expected";
            var key = $Object.keys(message.dependencies);
            for (var i = 0; i < key.length; ++i)
                if (!$util.isString(message.dependencies[key[i]]))
                    return "dependencies: string{k:string} expected";
        }
        if (message.devDependencies != null && $Object.hasOwnProperty.call(message, "devDependencies")) {
            if (!$util.isObject(message.devDependencies))
                return "devDependencies: object expected";
            var key = $Object.keys(message.devDependencies);
            for (var i = 0; i < key.length; ++i)
                if (!$util.isString(message.devDependencies[key[i]]))
                    return "devDependencies: string{k:string} expected";
        }
        if (message.types != null && $Object.hasOwnProperty.call(message, "types"))
            if (!$util.isString(message.types))
                return "types: string expected";
        if (message.cliDependencies != null && $Object.hasOwnProperty.call(message, "cliDependencies")) {
            if (!$Array.isArray(message.cliDependencies))
                return "cliDependencies: array expected";
            for (var i = 0; i < message.cliDependencies.length; ++i)
                if (!$util.isString(message.cliDependencies[i]))
                    return "cliDependencies: string[] expected";
        }
        return null;
    };

    /**
     * Creates a Package message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof Package
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {Package} Package
     */
    Package.fromObject = function (object, _depth) {
        if (object instanceof $root.Package)
            return object;
        if (!$util.isObject(object))
            throw $TypeError(".Package: object expected");
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            throw $Error("max depth exceeded");
        var message = new $root.Package();
        if (object.name != null)
            if (typeof object.name !== "string" || object.name.length)
                message.name = $String(object.name);
        if (object.version != null)
            if (typeof object.version !== "string" || object.version.length)
                message.version = $String(object.version);
        if (object.versionScheme != null)
            if (typeof object.versionScheme !== "string" || object.versionScheme.length)
                message.versionScheme = $String(object.versionScheme);
        if (object.description != null)
            if (typeof object.description !== "string" || object.description.length)
                message.description = $String(object.description);
        if (object.author != null)
            if (typeof object.author !== "string" || object.author.length)
                message.author = $String(object.author);
        if (object.license != null)
            if (typeof object.license !== "string" || object.license.length)
                message.license = $String(object.license);
        if (object.repository != null) {
            if (!$util.isObject(object.repository))
                throw $TypeError(".Package.repository: object expected");
            message.repository = $root.Package.Repository.fromObject(object.repository, _depth + 1);
        }
        if (object.bugs != null)
            if (typeof object.bugs !== "string" || object.bugs.length)
                message.bugs = $String(object.bugs);
        if (object.homepage != null)
            if (typeof object.homepage !== "string" || object.homepage.length)
                message.homepage = $String(object.homepage);
        if (object.keywords) {
            if (!$Array.isArray(object.keywords))
                throw $TypeError(".Package.keywords: array expected");
            message.keywords = $Array(object.keywords.length);
            for (var i = 0; i < object.keywords.length; ++i)
                message.keywords[i] = $String(object.keywords[i]);
        }
        if (object.main != null)
            if (typeof object.main !== "string" || object.main.length)
                message.main = $String(object.main);
        if (object.bin) {
            if (!$util.isObject(object.bin))
                throw $TypeError(".Package.bin: object expected");
            message.bin = {};
            for (var keys = $Object.keys(object.bin), i = 0; i < keys.length; ++i) {
                if (keys[i] === "__proto__")
                    $util.makeProp(message.bin, keys[i]);
                message.bin[keys[i]] = $String(object.bin[keys[i]]);
            }
        }
        if (object.scripts) {
            if (!$util.isObject(object.scripts))
                throw $TypeError(".Package.scripts: object expected");
            message.scripts = {};
            for (var keys = $Object.keys(object.scripts), i = 0; i < keys.length; ++i) {
                if (keys[i] === "__proto__")
                    $util.makeProp(message.scripts, keys[i]);
                message.scripts[keys[i]] = $String(object.scripts[keys[i]]);
            }
        }
        if (object.dependencies) {
            if (!$util.isObject(object.dependencies))
                throw $TypeError(".Package.dependencies: object expected");
            message.dependencies = {};
            for (var keys = $Object.keys(object.dependencies), i = 0; i < keys.length; ++i) {
                if (keys[i] === "__proto__")
                    $util.makeProp(message.dependencies, keys[i]);
                message.dependencies[keys[i]] = $String(object.dependencies[keys[i]]);
            }
        }
        if (object.devDependencies) {
            if (!$util.isObject(object.devDependencies))
                throw $TypeError(".Package.devDependencies: object expected");
            message.devDependencies = {};
            for (var keys = $Object.keys(object.devDependencies), i = 0; i < keys.length; ++i) {
                if (keys[i] === "__proto__")
                    $util.makeProp(message.devDependencies, keys[i]);
                message.devDependencies[keys[i]] = $String(object.devDependencies[keys[i]]);
            }
        }
        if (object.types != null)
            if (typeof object.types !== "string" || object.types.length)
                message.types = $String(object.types);
        if (object.cliDependencies) {
            if (!$Array.isArray(object.cliDependencies))
                throw $TypeError(".Package.cliDependencies: array expected");
            message.cliDependencies = $Array(object.cliDependencies.length);
            for (var i = 0; i < object.cliDependencies.length; ++i)
                message.cliDependencies[i] = $String(object.cliDependencies[i]);
        }
        return message;
    };

    /**
     * Creates a plain object from a Package message. Also converts values to other types if specified.
     * @function toObject
     * @memberof Package
     * @static
     * @param {Package} message Package
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */
    Package.toObject = function (message, options, _depth) {
        if (!options)
            options = {};
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            throw $Error("max depth exceeded");
        var object = {};
        if (options.arrays || options.defaults) {
            object.keywords = [];
            object.cliDependencies = [];
        }
        if (options.objects || options.defaults) {
            object.bin = {};
            object.scripts = {};
            object.dependencies = {};
            object.devDependencies = {};
        }
        if (options.defaults) {
            object.name = "";
            object.version = "";
            object.description = "";
            object.author = "";
            object.license = "";
            object.repository = null;
            object.bugs = "";
            object.homepage = "";
            object.main = "";
            object.types = "";
            object.versionScheme = "";
        }
        if (message.name != null && $Object.hasOwnProperty.call(message, "name"))
            object.name = message.name;
        if (message.version != null && $Object.hasOwnProperty.call(message, "version"))
            object.version = message.version;
        if (message.description != null && $Object.hasOwnProperty.call(message, "description"))
            object.description = message.description;
        if (message.author != null && $Object.hasOwnProperty.call(message, "author"))
            object.author = message.author;
        if (message.license != null && $Object.hasOwnProperty.call(message, "license"))
            object.license = message.license;
        if (message.repository != null && $Object.hasOwnProperty.call(message, "repository"))
            object.repository = $root.Package.Repository.toObject(message.repository, options, _depth + 1);
        if (message.bugs != null && $Object.hasOwnProperty.call(message, "bugs"))
            object.bugs = message.bugs;
        if (message.homepage != null && $Object.hasOwnProperty.call(message, "homepage"))
            object.homepage = message.homepage;
        if (message.keywords && message.keywords.length) {
            object.keywords = $Array(message.keywords.length);
            for (var j = 0; j < message.keywords.length; ++j)
                object.keywords[j] = message.keywords[j];
        }
        if (message.main != null && $Object.hasOwnProperty.call(message, "main"))
            object.main = message.main;
        var keys2;
        if (message.bin && (keys2 = $Object.keys(message.bin)).length) {
            object.bin = {};
            for (var j = 0; j < keys2.length; ++j) {
                if (keys2[j] === "__proto__")
                    $util.makeProp(object.bin, keys2[j]);
                object.bin[keys2[j]] = message.bin[keys2[j]];
            }
        }
        if (message.scripts && (keys2 = $Object.keys(message.scripts)).length) {
            object.scripts = {};
            for (var j = 0; j < keys2.length; ++j) {
                if (keys2[j] === "__proto__")
                    $util.makeProp(object.scripts, keys2[j]);
                object.scripts[keys2[j]] = message.scripts[keys2[j]];
            }
        }
        if (message.dependencies && (keys2 = $Object.keys(message.dependencies)).length) {
            object.dependencies = {};
            for (var j = 0; j < keys2.length; ++j) {
                if (keys2[j] === "__proto__")
                    $util.makeProp(object.dependencies, keys2[j]);
                object.dependencies[keys2[j]] = message.dependencies[keys2[j]];
            }
        }
        if (message.devDependencies && (keys2 = $Object.keys(message.devDependencies)).length) {
            object.devDependencies = {};
            for (var j = 0; j < keys2.length; ++j) {
                if (keys2[j] === "__proto__")
                    $util.makeProp(object.devDependencies, keys2[j]);
                object.devDependencies[keys2[j]] = message.devDependencies[keys2[j]];
            }
        }
        if (message.types != null && $Object.hasOwnProperty.call(message, "types"))
            object.types = message.types;
        if (message.cliDependencies && message.cliDependencies.length) {
            object.cliDependencies = $Array(message.cliDependencies.length);
            for (var j = 0; j < message.cliDependencies.length; ++j)
                object.cliDependencies[j] = message.cliDependencies[j];
        }
        if (message.versionScheme != null && $Object.hasOwnProperty.call(message, "versionScheme"))
            object.versionScheme = message.versionScheme;
        return object;
    };

    /**
     * Converts this Package to JSON.
     * @function toJSON
     * @memberof Package
     * @instance
     * @returns {Object.<string,*>} JSON object
     */
    Package.prototype.toJSON = function() {
        return Package.toObject(this, $protobuf.util.toJSONOptions);
    };

    /**
     * Gets the type url for Package
     * @function getTypeUrl
     * @memberof Package
     * @static
     * @param {string} [prefix] Custom type url prefix, defaults to `"type.googleapis.com"`
     * @returns {string} The type url
     */
    Package.getTypeUrl = function(prefix) {
        if (prefix === $undefined)
            prefix = "type.googleapis.com";
        return prefix + "/Package";
    };

    Package.Repository = (function() {

        /**
         * Properties of a Repository.
         * @typedef {Object} Package.Repository.$Properties
         * @property {string|null} [type] Repository type
         * @property {string|null} [url] Repository url
         * @property {Array.<Uint8Array>} [$unknowns] Unknown fields preserved while decoding when enabled
         */

        /**
         * Properties of a Repository.
         * @memberof Package
         * @interface IRepository
         * @augments Package.Repository.$Properties
         * @deprecated Use Package.Repository.$Properties instead.
         */

        /**
         * Shape of a Repository.
         * @typedef {Package.Repository.$Properties} Package.Repository.$Shape
         */

        /**
         * Constructs a new Repository.
         * @memberof Package
         * @classdesc Represents a Repository.
         * @constructor
         * @param {Package.Repository.$Properties=} [properties] Properties to set
         * @property {Array.<Uint8Array>} [$unknowns] Unknown fields preserved while decoding when enabled
         */
        var Repository = function (properties) {
            if (properties)
                for (var keys = $Object.keys(properties), i = 0; i < keys.length; ++i)
                    if (properties[keys[i]] != null && keys[i] !== "__proto__")
                        this[keys[i]] = properties[keys[i]];
        };

        /**
         * Repository type.
         * @member {string} type
         * @memberof Package.Repository
         * @instance
         */
        Repository.prototype.type = "";

        /**
         * Repository url.
         * @member {string} url
         * @memberof Package.Repository
         * @instance
         */
        Repository.prototype.url = "";

        /**
         * Creates a new Repository instance using the specified properties.
         * @function create
         * @memberof Package.Repository
         * @static
         * @param {Package.Repository.$Properties=} [properties] Properties to set
         * @returns {Package.Repository} Repository instance
         * @type {{
         *   (properties: Package.Repository.$Shape): Package.Repository & Package.Repository.$Shape;
         *   (properties?: Package.Repository.$Properties): Package.Repository;
         * }}
         */
        Repository.create = function(properties) {
            return new Repository(properties);
        };

        /**
         * Encodes the specified Repository message. Does not implicitly {@link Package.Repository.verify|verify} messages.
         * @function encode
         * @memberof Package.Repository
         * @static
         * @param {Package.Repository.$Properties} message Repository message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        Repository.encode = function (message, writer, _depth) {
            if (!writer)
                writer = $Writer.create();
            if (_depth === $undefined)
                _depth = 0;
            if (_depth > $util.recursionLimit)
                throw $Error("max depth exceeded");
            if (message.type != null && $Object.hasOwnProperty.call(message, "type") && message.type !== "")
                writer.uint32(/* id 1, wireType 2 =*/10).string(message.type);
            if (message.url != null && $Object.hasOwnProperty.call(message, "url") && message.url !== "")
                writer.uint32(/* id 2, wireType 2 =*/18).string(message.url);
            if (message.$unknowns != null && $Object.hasOwnProperty.call(message, "$unknowns"))
                for (var i = 0; i < message.$unknowns.length; ++i)
                    writer.raw(message.$unknowns[i]);
            return writer;
        };

        /**
         * Encodes the specified Repository message, length delimited. Does not implicitly {@link Package.Repository.verify|verify} messages.
         * @function encodeDelimited
         * @memberof Package.Repository
         * @static
         * @param {Package.Repository.$Properties} message Repository message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */
        Repository.encodeDelimited = function(message, writer) {
            return this.encode(message, (writer || $Writer.create()).fork()).ldelim();
        };

        /**
         * Decodes a Repository message from the specified reader or buffer.
         * @function decode
         * @memberof Package.Repository
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {Package.Repository & Package.Repository.$Shape} Repository
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        Repository.decode = function (reader, length, _end, _depth, _target) {
            if (!(reader instanceof $Reader))
                reader = $Reader.create(reader);
            if (_depth === $undefined)
                _depth = 0;
            if (_depth > $Reader.recursionLimit)
                throw $Error("max depth exceeded");
            var end, message, value;
            if (length === $undefined)
                end = reader.len;
            else {
                end = reader.pos + length;
                if (end > reader.len)
                    throw $RangeError("index out of range");
                length = reader.len;
                reader.len = end;
            }
            message = _target || new $root.Package.Repository();
            while (reader.pos < end) {
                var start = reader.pos;
                var tag = reader.tag();
                if (tag === _end) {
                    _end = $undefined;
                    break;
                }
                var wireType = tag & 7;
                switch (tag >>>= 3) {
                case 1: {
                        if (wireType !== 2)
                            break;
                        if ((value = reader.stringVerify()).length)
                            message.type = value;
                        else
                            delete message.type;
                        continue;
                    }
                case 2: {
                        if (wireType !== 2)
                            break;
                        if ((value = reader.stringVerify()).length)
                            message.url = value;
                        else
                            delete message.url;
                        continue;
                    }
                }
                reader.skipType(wireType, _depth, tag);
                if (!reader.discardUnknown) {
                    $util.makeProp(message, "$unknowns", false);
                    (message.$unknowns || (message.$unknowns = [])).push(reader.raw(start, reader.pos));
                }
            }
            if (length !== $undefined) {
                if (reader.pos !== end)
                    throw $RangeError("index out of range");
                reader.len = length;
            }
            if (_end !== $undefined)
                throw $Error("missing end group");
            return message;
        };

        /**
         * Decodes a Repository message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof Package.Repository
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {Package.Repository & Package.Repository.$Shape} Repository
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        Repository.decodeDelimited = function(reader) {
            if (!(reader instanceof $Reader))
                reader = new $Reader(reader);
            return this.decode(reader, reader.size());
        };

        /**
         * Verifies a Repository message.
         * @function verify
         * @memberof Package.Repository
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */
        Repository.verify = function (message, _depth) {
            if (typeof message !== "object" || message === null)
                return "object expected";
            if (_depth === $undefined)
                _depth = 0;
            if (_depth > $util.recursionLimit)
                return "max depth exceeded";
            if (message.type != null && $Object.hasOwnProperty.call(message, "type"))
                if (!$util.isString(message.type))
                    return "type: string expected";
            if (message.url != null && $Object.hasOwnProperty.call(message, "url"))
                if (!$util.isString(message.url))
                    return "url: string expected";
            return null;
        };

        /**
         * Creates a Repository message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof Package.Repository
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {Package.Repository} Repository
         */
        Repository.fromObject = function (object, _depth) {
            if (object instanceof $root.Package.Repository)
                return object;
            if (!$util.isObject(object))
                throw $TypeError(".Package.Repository: object expected");
            if (_depth === $undefined)
                _depth = 0;
            if (_depth > $util.recursionLimit)
                throw $Error("max depth exceeded");
            var message = new $root.Package.Repository();
            if (object.type != null)
                if (typeof object.type !== "string" || object.type.length)
                    message.type = $String(object.type);
            if (object.url != null)
                if (typeof object.url !== "string" || object.url.length)
                    message.url = $String(object.url);
            return message;
        };

        /**
         * Creates a plain object from a Repository message. Also converts values to other types if specified.
         * @function toObject
         * @memberof Package.Repository
         * @static
         * @param {Package.Repository} message Repository
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */
        Repository.toObject = function (message, options, _depth) {
            if (!options)
                options = {};
            if (_depth === $undefined)
                _depth = 0;
            if (_depth > $util.recursionLimit)
                throw $Error("max depth exceeded");
            var object = {};
            if (options.defaults) {
                object.type = "";
                object.url = "";
            }
            if (message.type != null && $Object.hasOwnProperty.call(message, "type"))
                object.type = message.type;
            if (message.url != null && $Object.hasOwnProperty.call(message, "url"))
                object.url = message.url;
            return object;
        };

        /**
         * Converts this Repository to JSON.
         * @function toJSON
         * @memberof Package.Repository
         * @instance
         * @returns {Object.<string,*>} JSON object
         */
        Repository.prototype.toJSON = function() {
            return Repository.toObject(this, $protobuf.util.toJSONOptions);
        };

        /**
         * Gets the type url for Repository
         * @function getTypeUrl
         * @memberof Package.Repository
         * @static
         * @param {string} [prefix] Custom type url prefix, defaults to `"type.googleapis.com"`
         * @returns {string} The type url
         */
        Repository.getTypeUrl = function(prefix) {
            if (prefix === $undefined)
                prefix = "type.googleapis.com";
            return prefix + "/Package.Repository";
        };

        return Repository;
    })();

    return Package;
})();

module.exports = $root;
