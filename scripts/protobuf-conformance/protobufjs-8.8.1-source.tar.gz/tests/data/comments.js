/*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-mixed-operators, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars, default-case, jsdoc/require-param*/
"use strict";

var $protobuf = require("../../minimal");

// Common aliases
var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;
var $Object = $util.global.Object, $undefined = $util.global.undefined, $Error = $util.global.Error, $RangeError = $util.global.RangeError, $TypeError = $util.global.TypeError, $String = $util.global.String, $Number = $util.global.Number, $Boolean = $util.global.Boolean;

// Exported root namespace
var $root = $protobuf.roots["test_comments"] || ($protobuf.roots["test_comments"] = {});

$root.Test1 = (function() {

    /**
     * Properties of a Test1.
     * @typedef {Object} Test1.$Properties
     * @property {string|null} [field1] Field with a comment.
     * @property {number|null} [field2] Test1 field2
     * @property {boolean|null} [field3] Field with a comment and a <a href="http://example.com/foo/">link</a>
     * @property {Array.<Uint8Array>} [$unknowns] Unknown fields preserved while decoding when enabled
     */

    /**
     * Properties of a Test1.
     * @exports ITest1
     * @interface ITest1
     * @augments Test1.$Properties
     * @deprecated Use Test1.$Properties instead.
     */

    /**
     * Shape of a Test1.
     * @typedef {Test1.$Properties} Test1.$Shape
     */

    /**
     * Constructs a new Test1.
     * @exports Test1
     * @classdesc Message
     * with
     * a
     * comment.
     * @constructor
     * @param {Test1.$Properties=} [properties] Properties to set
     * @property {Array.<Uint8Array>} [$unknowns] Unknown fields preserved while decoding when enabled
     */
    var Test1 = function (properties) {
        if (properties)
            for (var keys = $Object.keys(properties), i = 0; i < keys.length; ++i)
                if (properties[keys[i]] != null && keys[i] !== "__proto__")
                    this[keys[i]] = properties[keys[i]];
    };

    /**
     * Field with a comment.
     * @member {string} field1
     * @memberof Test1
     * @instance
     */
    Test1.prototype.field1 = "";

    /**
     * Test1 field2.
     * @member {number} field2
     * @memberof Test1
     * @instance
     */
    Test1.prototype.field2 = 0;

    /**
     * Field with a comment and a <a href="http://example.com/foo/">link</a>
     * @member {boolean} field3
     * @memberof Test1
     * @instance
     */
    Test1.prototype.field3 = false;

    /**
     * Creates a new Test1 instance using the specified properties.
     * @function create
     * @memberof Test1
     * @static
     * @param {Test1.$Properties=} [properties] Properties to set
     * @returns {Test1} Test1 instance
     * @type {{
     *   (properties: Test1.$Shape): Test1 & Test1.$Shape;
     *   (properties?: Test1.$Properties): Test1;
     * }}
     */
    Test1.create = function(properties) {
        return new Test1(properties);
    };

    /**
     * Encodes the specified Test1 message. Does not implicitly {@link Test1.verify|verify} messages.
     * @function encode
     * @memberof Test1
     * @static
     * @param {Test1.$Properties} message Test1 message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */
    Test1.encode = function (message, writer, _depth) {
        if (!writer)
            writer = $Writer.create();
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            throw $Error("max depth exceeded");
        if (message.field1 != null && $Object.hasOwnProperty.call(message, "field1") && message.field1 !== "")
            writer.uint32(/* id 1, wireType 2 =*/10).string(message.field1);
        if (message.field2 != null && $Object.hasOwnProperty.call(message, "field2") && message.field2 !== 0)
            writer.uint32(/* id 2, wireType 0 =*/16).uint32(message.field2);
        if (message.field3 != null && $Object.hasOwnProperty.call(message, "field3") && message.field3 !== false)
            writer.uint32(/* id 3, wireType 0 =*/24).bool(message.field3);
        if (message.$unknowns != null && $Object.hasOwnProperty.call(message, "$unknowns"))
            for (var i = 0; i < message.$unknowns.length; ++i)
                writer.raw(message.$unknowns[i]);
        return writer;
    };

    /**
     * Encodes the specified Test1 message, length delimited. Does not implicitly {@link Test1.verify|verify} messages.
     * @function encodeDelimited
     * @memberof Test1
     * @static
     * @param {Test1.$Properties} message Test1 message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */
    Test1.encodeDelimited = function(message, writer) {
        return this.encode(message, (writer || $Writer.create()).fork()).ldelim();
    };

    /**
     * Decodes a Test1 message from the specified reader or buffer.
     * @function decode
     * @memberof Test1
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {Test1 & Test1.$Shape} Test1
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */
    Test1.decode = function (reader, length, _end, _depth, _target) {
        if (!(reader instanceof $Reader))
            reader = $Reader.create(reader);
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $Reader.recursionLimit)
            throw $Error("max depth exceeded");
        var end, message, value;
        if (length === $undefined)
            end = reader.len;
        else {
            end = reader.pos + length;
            if (end > reader.len)
                throw $RangeError("index out of range");
            length = reader.len;
            reader.len = end;
        }
        message = _target || new $root.Test1();
        while (reader.pos < end) {
            var start = reader.pos;
            var tag = reader.tag();
            if (tag === _end) {
                _end = $undefined;
                break;
            }
            var wireType = tag & 7;
            switch (tag >>>= 3) {
            case 1: {
                    if (wireType !== 2)
                        break;
                    if ((value = reader.stringVerify()).length)
                        message.field1 = value;
                    else
                        delete message.field1;
                    continue;
                }
            case 2: {
                    if (wireType !== 0)
                        break;
                    if (value = reader.uint32())
                        message.field2 = value;
                    else
                        delete message.field2;
                    continue;
                }
            case 3: {
                    if (wireType !== 0)
                        break;
                    if (value = reader.bool())
                        message.field3 = value;
                    else
                        delete message.field3;
                    continue;
                }
            }
            reader.skipType(wireType, _depth, tag);
            if (!reader.discardUnknown) {
                $util.makeProp(message, "$unknowns", false);
                (message.$unknowns || (message.$unknowns = [])).push(reader.raw(start, reader.pos));
            }
        }
        if (length !== $undefined) {
            if (reader.pos !== end)
                throw $RangeError("index out of range");
            reader.len = length;
        }
        if (_end !== $undefined)
            throw $Error("missing end group");
        return message;
    };

    /**
     * Decodes a Test1 message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof Test1
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {Test1 & Test1.$Shape} Test1
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */
    Test1.decodeDelimited = function(reader) {
        if (!(reader instanceof $Reader))
            reader = new $Reader(reader);
        return this.decode(reader, reader.size());
    };

    /**
     * Verifies a Test1 message.
     * @function verify
     * @memberof Test1
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */
    Test1.verify = function (message, _depth) {
        if (typeof message !== "object" || message === null)
            return "object expected";
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            return "max depth exceeded";
        if (message.field1 != null && $Object.hasOwnProperty.call(message, "field1"))
            if (!$util.isString(message.field1))
                return "field1: string expected";
        if (message.field2 != null && $Object.hasOwnProperty.call(message, "field2"))
            if (!$util.isInteger(message.field2))
                return "field2: integer expected";
        if (message.field3 != null && $Object.hasOwnProperty.call(message, "field3"))
            if (typeof message.field3 !== "boolean")
                return "field3: boolean expected";
        return null;
    };

    /**
     * Creates a Test1 message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof Test1
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {Test1} Test1
     */
    Test1.fromObject = function (object, _depth) {
        if (object instanceof $root.Test1)
            return object;
        if (!$util.isObject(object))
            throw $TypeError(".Test1: object expected");
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            throw $Error("max depth exceeded");
        var message = new $root.Test1();
        if (object.field1 != null)
            if (typeof object.field1 !== "string" || object.field1.length)
                message.field1 = $String(object.field1);
        if (object.field2 != null)
            if ($Number(object.field2) !== 0)
                message.field2 = object.field2 >>> 0;
        if (object.field3 != null)
            if (object.field3)
                message.field3 = $Boolean(object.field3);
        return message;
    };

    /**
     * Creates a plain object from a Test1 message. Also converts values to other types if specified.
     * @function toObject
     * @memberof Test1
     * @static
     * @param {Test1} message Test1
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */
    Test1.toObject = function (message, options, _depth) {
        if (!options)
            options = {};
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            throw $Error("max depth exceeded");
        var object = {};
        if (options.defaults) {
            object.field1 = "";
            object.field2 = 0;
            object.field3 = false;
        }
        if (message.field1 != null && $Object.hasOwnProperty.call(message, "field1"))
            object.field1 = message.field1;
        if (message.field2 != null && $Object.hasOwnProperty.call(message, "field2"))
            object.field2 = message.field2;
        if (message.field3 != null && $Object.hasOwnProperty.call(message, "field3"))
            object.field3 = message.field3;
        return object;
    };

    /**
     * Converts this Test1 to JSON.
     * @function toJSON
     * @memberof Test1
     * @instance
     * @returns {Object.<string,*>} JSON object
     */
    Test1.prototype.toJSON = function() {
        return Test1.toObject(this, $protobuf.util.toJSONOptions);
    };

    /**
     * Gets the type url for Test1
     * @function getTypeUrl
     * @memberof Test1
     * @static
     * @param {string} [prefix] Custom type url prefix, defaults to `"type.googleapis.com"`
     * @returns {string} The type url
     */
    Test1.getTypeUrl = function(prefix) {
        if (prefix === $undefined)
            prefix = "type.googleapis.com";
        return prefix + "/Test1";
    };

    return Test1;
})();

$root.Test2 = (function() {

    /**
     * Properties of a Test2.
     * @typedef {Object} Test2.$Properties
     * @property {Array.<Uint8Array>} [$unknowns] Unknown fields preserved while decoding when enabled
     */

    /**
     * Properties of a Test2.
     * @exports ITest2
     * @interface ITest2
     * @augments Test2.$Properties
     * @deprecated Use Test2.$Properties instead.
     */

    /**
     * Shape of a Test2.
     * @typedef {Test2.$Properties} Test2.$Shape
     */

    /**
     * Constructs a new Test2.
     * @exports Test2
     * @classdesc Represents a Test2.
     * @constructor
     * @param {Test2.$Properties=} [properties] Properties to set
     * @property {Array.<Uint8Array>} [$unknowns] Unknown fields preserved while decoding when enabled
     */
    var Test2 = function (properties) {
        if (properties)
            for (var keys = $Object.keys(properties), i = 0; i < keys.length; ++i)
                if (properties[keys[i]] != null && keys[i] !== "__proto__")
                    this[keys[i]] = properties[keys[i]];
    };

    /**
     * Creates a new Test2 instance using the specified properties.
     * @function create
     * @memberof Test2
     * @static
     * @param {Test2.$Properties=} [properties] Properties to set
     * @returns {Test2} Test2 instance
     * @type {{
     *   (properties: Test2.$Shape): Test2 & Test2.$Shape;
     *   (properties?: Test2.$Properties): Test2;
     * }}
     */
    Test2.create = function(properties) {
        return new Test2(properties);
    };

    /**
     * Encodes the specified Test2 message. Does not implicitly {@link Test2.verify|verify} messages.
     * @function encode
     * @memberof Test2
     * @static
     * @param {Test2.$Properties} message Test2 message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */
    Test2.encode = function (message, writer, _depth) {
        if (!writer)
            writer = $Writer.create();
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            throw $Error("max depth exceeded");
        if (message.$unknowns != null && $Object.hasOwnProperty.call(message, "$unknowns"))
            for (var i = 0; i < message.$unknowns.length; ++i)
                writer.raw(message.$unknowns[i]);
        return writer;
    };

    /**
     * Encodes the specified Test2 message, length delimited. Does not implicitly {@link Test2.verify|verify} messages.
     * @function encodeDelimited
     * @memberof Test2
     * @static
     * @param {Test2.$Properties} message Test2 message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */
    Test2.encodeDelimited = function(message, writer) {
        return this.encode(message, (writer || $Writer.create()).fork()).ldelim();
    };

    /**
     * Decodes a Test2 message from the specified reader or buffer.
     * @function decode
     * @memberof Test2
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {Test2 & Test2.$Shape} Test2
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */
    Test2.decode = function (reader, length, _end, _depth, _target) {
        if (!(reader instanceof $Reader))
            reader = $Reader.create(reader);
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $Reader.recursionLimit)
            throw $Error("max depth exceeded");
        var end, message;
        if (length === $undefined)
            end = reader.len;
        else {
            end = reader.pos + length;
            if (end > reader.len)
                throw $RangeError("index out of range");
            length = reader.len;
            reader.len = end;
        }
        message = _target || new $root.Test2();
        while (reader.pos < end) {
            var start = reader.pos;
            var tag = reader.tag();
            if (tag === _end) {
                _end = $undefined;
                break;
            }
            reader.skipType(tag & 7, _depth, tag);
            if (!reader.discardUnknown) {
                $util.makeProp(message, "$unknowns", false);
                (message.$unknowns || (message.$unknowns = [])).push(reader.raw(start, reader.pos));
            }
        }
        if (length !== $undefined) {
            if (reader.pos !== end)
                throw $RangeError("index out of range");
            reader.len = length;
        }
        if (_end !== $undefined)
            throw $Error("missing end group");
        return message;
    };

    /**
     * Decodes a Test2 message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof Test2
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {Test2 & Test2.$Shape} Test2
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */
    Test2.decodeDelimited = function(reader) {
        if (!(reader instanceof $Reader))
            reader = new $Reader(reader);
        return this.decode(reader, reader.size());
    };

    /**
     * Verifies a Test2 message.
     * @function verify
     * @memberof Test2
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */
    Test2.verify = function (message, _depth) {
        if (typeof message !== "object" || message === null)
            return "object expected";
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            return "max depth exceeded";
        return null;
    };

    /**
     * Creates a Test2 message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof Test2
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {Test2} Test2
     */
    Test2.fromObject = function (object, _depth) {
        if (object instanceof $root.Test2)
            return object;
        if (!$util.isObject(object))
            throw $TypeError(".Test2: object expected");
        if (_depth === $undefined)
            _depth = 0;
        if (_depth > $util.recursionLimit)
            throw $Error("max depth exceeded");
        return new $root.Test2();
    };

    /**
     * Creates a plain object from a Test2 message. Also converts values to other types if specified.
     * @function toObject
     * @memberof Test2
     * @static
     * @param {Test2} message Test2
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */
    Test2.toObject = function () {
        return {};
    };

    /**
     * Converts this Test2 to JSON.
     * @function toJSON
     * @memberof Test2
     * @instance
     * @returns {Object.<string,*>} JSON object
     */
    Test2.prototype.toJSON = function() {
        return Test2.toObject(this, $protobuf.util.toJSONOptions);
    };

    /**
     * Gets the type url for Test2
     * @function getTypeUrl
     * @memberof Test2
     * @static
     * @param {string} [prefix] Custom type url prefix, defaults to `"type.googleapis.com"`
     * @returns {string} The type url
     */
    Test2.getTypeUrl = function(prefix) {
        if (prefix === $undefined)
            prefix = "type.googleapis.com";
        return prefix + "/Test2";
    };

    return Test2;
})();

/**
 * Test3 enum.
 * @name Test3
 * @enum {number}
 * @property {number} ONE=1 Value with a comment.
 * @property {number} TWO=2 TWO value
 * @property {number} THREE=3 Preferred value with a comment.
 * @property {number} FOUR=4 Other value with a comment.
 * @property {number} FIVE=5 Leading comment for value with both types of comments after field with trailing comment.
 */
$root.Test3 = (function() {
    var valuesById = $Object.create(null), values = $Object.create(valuesById);
    values[valuesById[1] = "ONE"] = 1;
    values[valuesById[2] = "TWO"] = 2;
    values[valuesById[3] = "THREE"] = 3;
    values[valuesById[4] = "FOUR"] = 4;
    values[valuesById[5] = "FIVE"] = 5;
    return values;
})();

module.exports = $root;
