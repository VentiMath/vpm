var tape = require("tape");

var protobuf = require("../..");

tape.test("load sync", function(test) {
    var root = protobuf.loadSync("tests/data/common.proto");

    test.ok(root.lookup("Something"), "should parse message Something");

    test.throws(function() {
        protobuf.loadSync("tests/data/__NOTFOUND__", root);
    }, Error, "should throw if not found");

    var isNode = protobuf.util.isNode;
    try {
        protobuf.util.isNode = false;
        test.throws(function() {
            protobuf.loadSync("tests/data/common.proto");
        }, "should throw when not running under node");
    } finally {
        protobuf.util.isNode = isNode;
    }

    test.throws(function() {
        protobuf.loadSync("tests/data/invalid.proto");
    }, Error, "should throw when trying to load an invalid proto");

    test.throws(function() {
        protobuf.loadSync("tests/data/invalid.json");
    }, Error, "should throw when trying to load invalid json");

    root = protobuf.loadSync("tests/data/weak.proto");
    test.ok(root.files.indexOf("tests/data/NOT_FOUND") > -1, "should ignore missing weak protos and remember them");
    test.ok(root.files.indexOf("google/protobuf/any.proto") > -1, "should still load other protos when ignoring weak protos");

    test.end();
});

tape.test("load sync import recursion limit", function(test) {
    var fs = protobuf.util.fs,
        readFileSync = fs.readFileSync,
        recursionLimit = protobuf.util.recursionLimit;

    protobuf.util.recursionLimit = 3;
    fs.readFileSync = function(filename) {
        var match = /chain-(\d+)\.proto$/.exec(filename);
        if (match)
            return "syntax = \"proto3\";\nimport \"chain-" + (Number(match[1]) + 1) + ".proto\";\n";
        return readFileSync.apply(this, arguments);
    };

    try {
        var root = new protobuf.Root();
        root.resolvePath = function(origin, target) {
            return target;
        };
        test.throws(function() {
            root.loadSync("chain-0.proto");
        }, /max depth exceeded/, "should reject excessive import nesting");
    } finally {
        fs.readFileSync = readFileSync;
        protobuf.util.recursionLimit = recursionLimit;
    }

    test.end();
});

tape.test("should load bundled definitions even if resolvePath method was overrided", function(test) {
    var protoFilePath = "tests/data/common.proto";
    var root = new protobuf.Root();
    root.resolvePath = (origin, target) => origin === "" && target === protoFilePath ? target : null;

    root.loadSync(protoFilePath);

    test.ok(root.lookup("Something"), "should parse message Something");
    test.end();
});

tape.test("should load custom common definitions by full file name", function(test) {
    protobuf.common("custom/common.proto", {
        nested: {
            custom: {
                nested: {
                    CommonMessage: {
                        fields: {}
                    }
                }
            }
        }
    });

    try {
        var root = protobuf.loadSync("tests/data/common-custom.proto");

        test.ok(root.files.indexOf("custom/common.proto") > -1, "should track the custom common file name");
        test.ok(root.lookup("custom.CommonMessage"), "should load the custom common type");
        test.ok(root.lookup("UsesCustomCommon"), "should parse the importing message");
    } catch (err) {
        test.fail(err && err.message || err);
    } finally {
        delete protobuf.common["custom/common.proto"];
        test.end();
    }
});
